/* ==========================================
  NU-CLARK LIBRARY PORTAL
  BASIC LOGIN SYSTEM FOR SCHOOL DEMONSTRATION
  ========================================== */

/*
  localStorage allows the browser to remember
  information even when the student changes pages.
  We only store:
  - login status
  - first name
  - last name
  - student number
  We DO NOT store the password.
*/

// Find the login form on login.html.
const loginForm = document.getElementById("loginForm");

/*
  This code only runs if the current page
  contains the login form.
*/
if (loginForm) {
   loginForm.addEventListener("submit", function(event) {
       /*
          Normally submitting a form refreshes the page.
          preventDefault() stops that default behavior.
       */
       event.preventDefault();

       // Get the information entered by the student.
       const firstName =
           document.getElementById("firstname").value;
       const lastName =
           document.getElementById("lastname").value;
       const studentNumber =
           document.getElementById("studentNumber").value;

       /*
          Remember that the student has logged in.
          This is only a demonstration login.
       */
       localStorage.setItem("isLoggedIn", "true");
       localStorage.setItem("firstName", firstName);
       localStorage.setItem("lastName", lastName);
       localStorage.setItem("studentNumber", studentNumber);

       /*
          After successful form submission,
          return the student to the Home page.
       */
       window.location.href = "index.html";
   });
}

/* ==========================================
  PROTECTED LINKS
  ========================================== */

/*
  Find every link containing data-protected.
  These are pages that require login.
*/
const protectedLinks =
   document.querySelectorAll("[data-protected]");

protectedLinks.forEach(function(link) {
   link.addEventListener("click", function(event) {
       const loggedIn =
           localStorage.getItem("isLoggedIn");

       /*
          If the student is NOT logged in,
          stop the link from opening.
       */
       if (loggedIn !== "true") {
           event.preventDefault();
           alert(
               "Please log in first to access this library service."
           );
           window.location.href = "login.html";
       }
   });
});

/* ==========================================
  LOGIN / LOGOUT NAVIGATION
  ========================================== */
const loginNav =
   document.getElementById("loginNav");

if (loginNav) {
   const loggedIn =
       localStorage.getItem("isLoggedIn");

   /*
      If logged in, change Login into Logout.
   */
   if (loggedIn === "true") {
       loginNav.textContent = "Logout";
       loginNav.href = "#";

       loginNav.addEventListener("click", function(event) {
           event.preventDefault();

           // Remove the saved login information.
           localStorage.removeItem("isLoggedIn");
           localStorage.removeItem("firstName");
           localStorage.removeItem("lastName");
           localStorage.removeItem("studentNumber");

           alert("You have been logged out.");
           window.location.href = "index.html";
       });
   }
}